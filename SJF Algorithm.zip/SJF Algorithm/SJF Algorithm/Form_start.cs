﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SJF_Algorithm
{
    public partial class Form_stat : Form
    {
        public Form_stat()
        {
            InitializeComponent();
        }

        private void but_start_Click(object sender, EventArgs e)
        {
            Form_inputproc form2 = new Form_inputproc();
            form2.Show();
            form2.Location = Location;
            Hide();
        }
    }
}

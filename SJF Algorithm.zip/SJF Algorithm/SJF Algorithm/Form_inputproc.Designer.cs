﻿namespace SJF_Algorithm
{
    partial class Form_inputproc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_proc = new System.Windows.Forms.Label();
            this.numer_arrival = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.but_add = new System.Windows.Forms.Button();
            this.panel_proc = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numer_burst = new System.Windows.Forms.NumericUpDown();
            this.but_back = new System.Windows.Forms.Button();
            this.but_next = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numer_arrival)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel_proc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numer_burst)).BeginInit();
            this.SuspendLayout();
            // 
            // label_proc
            // 
            this.label_proc.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_proc.Location = new System.Drawing.Point(82, 75);
            this.label_proc.Name = "label_proc";
            this.label_proc.Size = new System.Drawing.Size(108, 36);
            this.label_proc.TabIndex = 0;
            this.label_proc.Text = "Process 1";
            // 
            // numer_arrival
            // 
            this.numer_arrival.Location = new System.Drawing.Point(226, 75);
            this.numer_arrival.Name = "numer_arrival";
            this.numer_arrival.Size = new System.Drawing.Size(81, 48);
            this.numer_arrival.TabIndex = 1;
            this.numer_arrival.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.but_add);
            this.groupBox1.Controls.Add(this.panel_proc);
            this.groupBox1.Font = new System.Drawing.Font("PT Bold Broken", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupBox1.Location = new System.Drawing.Point(57, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(767, 481);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Processes";
            // 
            // but_add
            // 
            this.but_add.Location = new System.Drawing.Point(685, 53);
            this.but_add.Name = "but_add";
            this.but_add.Size = new System.Drawing.Size(81, 52);
            this.but_add.TabIndex = 4;
            this.but_add.Text = "Add";
            this.but_add.UseVisualStyleBackColor = true;
            this.but_add.Click += new System.EventHandler(this.but_add_Click);
            // 
            // panel_proc
            // 
            this.panel_proc.AutoScroll = true;
            this.panel_proc.Controls.Add(this.label3);
            this.panel_proc.Controls.Add(this.label2);
            this.panel_proc.Controls.Add(this.label_proc);
            this.panel_proc.Controls.Add(this.numer_burst);
            this.panel_proc.Controls.Add(this.numer_arrival);
            this.panel_proc.Location = new System.Drawing.Point(65, 47);
            this.panel_proc.Name = "panel_proc";
            this.panel_proc.Size = new System.Drawing.Size(613, 428);
            this.panel_proc.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(420, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Burst time (ms)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(223, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Arrival time (ms)";
            // 
            // numer_burst
            // 
            this.numer_burst.Location = new System.Drawing.Point(423, 75);
            this.numer_burst.Name = "numer_burst";
            this.numer_burst.Size = new System.Drawing.Size(81, 48);
            this.numer_burst.TabIndex = 1;
            this.numer_burst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // but_back
            // 
            this.but_back.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold);
            this.but_back.Location = new System.Drawing.Point(12, 518);
            this.but_back.Name = "but_back";
            this.but_back.Size = new System.Drawing.Size(202, 64);
            this.but_back.TabIndex = 3;
            this.but_back.Text = "Back";
            this.but_back.UseVisualStyleBackColor = true;
            this.but_back.Click += new System.EventHandler(this.but_back_Click);
            // 
            // but_next
            // 
            this.but_next.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold);
            this.but_next.Location = new System.Drawing.Point(645, 518);
            this.but_next.Name = "but_next";
            this.but_next.Size = new System.Drawing.Size(202, 64);
            this.but_next.TabIndex = 4;
            this.but_next.Text = "Next";
            this.but_next.UseVisualStyleBackColor = true;
            this.but_next.Click += new System.EventHandler(this.but_next_Click);
            // 
            // Form_inputproc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 588);
            this.Controls.Add(this.but_next);
            this.Controls.Add(this.but_back);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form_inputproc";
            this.Text = "Form_inputproc";
            this.Load += new System.EventHandler(this.Form_inputproc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numer_arrival)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.panel_proc.ResumeLayout(false);
            this.panel_proc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numer_burst)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_proc;
        private System.Windows.Forms.NumericUpDown numer_arrival;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel_proc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numer_burst;
        private System.Windows.Forms.Button but_back;
        private System.Windows.Forms.Button but_next;
        private System.Windows.Forms.Button but_add;
    }
}
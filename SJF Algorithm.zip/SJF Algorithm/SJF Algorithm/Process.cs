﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SJF_Algorithm
{
    class Process
    {
        public Process()
        {

        }
        public int arrival;
        public int index;
        public int burst_time;
        public int priority;

        public Process(int i, int a, int b, int p)
        {
            arrival=a;
            index=i;
            burst_time=b;
            priority=p;

        }
        public static void sort1(List<Process> l)
        {
            for (int i = 0; i < l.Count; i++)
            {
                for (int j = 0; j < l.Count; j++)
                {
                    if (l[i].arrival < l[j].arrival)
                    {
                        Process temp = l[i];
                        l[i] = l[j];
                        l[j] = temp;
                    }
                }
            }
        }
        public static void sort2(List<Process> l)
        {
            for (int i = 0; i < l.Count; i++)
            {
                for (int j = 0; j < l.Count; j++)
                {
                    if (l[i].burst_time < l[j].burst_time)
                    {
                        Process temp = l[i];
                        l[i] = l[j];
                        l[j] = temp;
                    }
                }
            }
        }
    }
}

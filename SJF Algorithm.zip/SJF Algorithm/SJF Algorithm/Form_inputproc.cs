﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace SJF_Algorithm
{
    public partial class Form_inputproc : Form
    {
        public static int i;
        int z;
        int counter;
        NumericUpDown[] arrival;
        NumericUpDown[] brust;

        public static int[] cpu_brustTime;
        public static int[] arrivalTime;
        public static int[] priority;
        public Form_inputproc()
        {
            InitializeComponent();
            arrival =new NumericUpDown[50];
            brust = new NumericUpDown[50];
            cpu_brustTime = new int[50];
            arrivalTime = new int[50];
            priority = new int[50];

            z = 60;
            
        }
        
        private void but_back_Click(object sender, EventArgs e)
        {
            Form_stat formstr = new Form_stat();
            formstr.Show();
            formstr.Location = Location;
            Hide();
        }

        private void but_next_Click(object sender, EventArgs e)
        {
            for (int j = 0; j <= i; j++)
            {
                cpu_brustTime[j] = (int)brust[j].Value;
                arrivalTime[j] = (int)arrival[j].Value;
                priority[j] = -1;
            }
            Form_results result = new Form_results();
            result.Show();
            Hide();
        }

        private void but_add_Click(object sender, EventArgs e)
        {


            add();
        }
        
        private void add()
        {
            Label old_label = new Label();
            old_label = label_proc;
            old_label.Visible = true;
            Label new_label = new Label();
            new_label.Size = old_label.Size;
            new_label.Location = new Point(old_label.Location.X, old_label.Location.Y + z);
            int x = counter + 1;
            new_label.Text = "Process" + (i+2);
            new_label.Font = old_label.Font;
            new_label.BackColor = old_label.BackColor;
            new_label.TextAlign = old_label.TextAlign;
            new_label.Visible = true;
            panel_proc.Controls.Add(new_label);
            i += 1;
            NumericUpDown old_num = new NumericUpDown();
            old_num = numer_arrival;
            old_num.Enabled = true;
            arrival[0] = numer_arrival;
            NumericUpDown num = new NumericUpDown();
            num.Size = old_num.Size;
            num.Maximum = old_num.Maximum;
            num.Minimum = old_num.Minimum;
            num.TextAlign = old_num.TextAlign;
            num.Enabled = old_num.Enabled;
            num.Location = new Point(old_num.Location.X, old_num.Location.Y + z);
            arrival[i] = num;
            panel_proc.Controls.Add(num);

            NumericUpDown old = new NumericUpDown();
            old = numer_burst;
            old.Enabled = true;
            brust[0] = numer_burst;
            NumericUpDown new_num = new NumericUpDown();
            new_num.Size = old.Size;
            new_num.Maximum = old.Maximum;
            new_num.Minimum = old.Minimum;
            new_num.TextAlign = old.TextAlign;
            new_num.Location = new Point(old.Location.X, old.Location.Y + z);
            new_num.Enabled = old.Enabled;
            brust[i] = new_num;
            panel_proc.Controls.Add(new_num);
            z += 60;
        }

        private void Form_inputproc_Load(object sender, EventArgs e)
        {

        }
    }
}

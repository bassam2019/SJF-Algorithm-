﻿namespace SJF_Algorithm
{
    partial class Form_results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl_GanttChart = new System.Windows.Forms.TabControl();
            this.tabPage_GanttChart = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_freeTime = new System.Windows.Forms.Label();
            this.panel_ex_0 = new System.Windows.Forms.Panel();
            this.lbl_p1 = new System.Windows.Forms.Label();
            this.lbl_p1_turnaroundTime = new System.Windows.Forms.Label();
            this.lbl_p1_waitingTime = new System.Windows.Forms.Label();
            this.lbl_turnaroundTime_l = new System.Windows.Forms.Label();
            this.lbl_contextSwitch = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_waitingTime_l = new System.Windows.Forms.Label();
            this.lbl_avg_waitingTime = new System.Windows.Forms.Label();
            this.panel_ex_1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.tabControl_GanttChart.SuspendLayout();
            this.tabPage_GanttChart.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl_GanttChart
            // 
            this.tabControl_GanttChart.Controls.Add(this.tabPage_GanttChart);
            this.tabControl_GanttChart.Location = new System.Drawing.Point(28, 16);
            this.tabControl_GanttChart.Name = "tabControl_GanttChart";
            this.tabControl_GanttChart.SelectedIndex = 0;
            this.tabControl_GanttChart.Size = new System.Drawing.Size(701, 153);
            this.tabControl_GanttChart.TabIndex = 0;
            // 
            // tabPage_GanttChart
            // 
            this.tabPage_GanttChart.AutoScroll = true;
            this.tabPage_GanttChart.Controls.Add(this.label5);
            this.tabPage_GanttChart.Controls.Add(this.label6);
            this.tabPage_GanttChart.Controls.Add(this.label7);
            this.tabPage_GanttChart.Controls.Add(this.label4);
            this.tabPage_GanttChart.Controls.Add(this.label3);
            this.tabPage_GanttChart.Location = new System.Drawing.Point(4, 25);
            this.tabPage_GanttChart.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage_GanttChart.Name = "tabPage_GanttChart";
            this.tabPage_GanttChart.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage_GanttChart.Size = new System.Drawing.Size(693, 124);
            this.tabPage_GanttChart.TabIndex = 0;
            this.tabPage_GanttChart.Text = "Gantt Chart";
            this.tabPage_GanttChart.UseVisualStyleBackColor = true;
            this.tabPage_GanttChart.Click += new System.EventHandler(this.tabPage_GanttChart_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(52, 80);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "0";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(7, 80);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 23);
            this.label6.TabIndex = 3;
            this.label6.Text = "0";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 1.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(26, 21);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(1, 62);
            this.label7.TabIndex = 2;
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.UseCompatibleTextRendering = true;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 1.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(78, 21);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1, 62);
            this.label4.TabIndex = 1;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.UseCompatibleTextRendering = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(26, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 37);
            this.label3.TabIndex = 0;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.UseCompatibleTextRendering = true;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.lbl_freeTime);
            this.panel1.Controls.Add(this.panel_ex_0);
            this.panel1.Controls.Add(this.lbl_p1);
            this.panel1.Controls.Add(this.lbl_p1_turnaroundTime);
            this.panel1.Controls.Add(this.lbl_p1_waitingTime);
            this.panel1.Controls.Add(this.lbl_turnaroundTime_l);
            this.panel1.Controls.Add(this.lbl_contextSwitch);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lbl_waitingTime_l);
            this.panel1.Controls.Add(this.lbl_avg_waitingTime);
            this.panel1.Controls.Add(this.panel_ex_1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.tabControl_GanttChart);
            this.panel1.Location = new System.Drawing.Point(44, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(752, 456);
            this.panel1.TabIndex = 1;
            // 
            // lbl_freeTime
            // 
            this.lbl_freeTime.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_freeTime.Location = new System.Drawing.Point(547, 228);
            this.lbl_freeTime.Name = "lbl_freeTime";
            this.lbl_freeTime.Size = new System.Drawing.Size(100, 23);
            this.lbl_freeTime.TabIndex = 12;
            this.lbl_freeTime.Text = "Free time";
            this.lbl_freeTime.Click += new System.EventHandler(this.lbl_freeTime_Click);
            // 
            // panel_ex_0
            // 
            this.panel_ex_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel_ex_0.Location = new System.Drawing.Point(488, 228);
            this.panel_ex_0.Name = "panel_ex_0";
            this.panel_ex_0.Size = new System.Drawing.Size(31, 28);
            this.panel_ex_0.TabIndex = 11;
            // 
            // lbl_p1
            // 
            this.lbl_p1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p1.Location = new System.Drawing.Point(50, 226);
            this.lbl_p1.Name = "lbl_p1";
            this.lbl_p1.Size = new System.Drawing.Size(100, 23);
            this.lbl_p1.TabIndex = 10;
            this.lbl_p1.Text = "Processes1";
            // 
            // lbl_p1_turnaroundTime
            // 
            this.lbl_p1_turnaroundTime.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p1_turnaroundTime.Location = new System.Drawing.Point(300, 226);
            this.lbl_p1_turnaroundTime.Name = "lbl_p1_turnaroundTime";
            this.lbl_p1_turnaroundTime.Size = new System.Drawing.Size(32, 31);
            this.lbl_p1_turnaroundTime.TabIndex = 9;
            this.lbl_p1_turnaroundTime.Text = "0";
            // 
            // lbl_p1_waitingTime
            // 
            this.lbl_p1_waitingTime.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p1_waitingTime.Location = new System.Drawing.Point(183, 226);
            this.lbl_p1_waitingTime.Name = "lbl_p1_waitingTime";
            this.lbl_p1_waitingTime.Size = new System.Drawing.Size(32, 31);
            this.lbl_p1_waitingTime.TabIndex = 8;
            this.lbl_p1_waitingTime.Text = "0";
            // 
            // lbl_turnaroundTime_l
            // 
            this.lbl_turnaroundTime_l.AutoSize = true;
            this.lbl_turnaroundTime_l.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_turnaroundTime_l.Location = new System.Drawing.Point(255, 194);
            this.lbl_turnaroundTime_l.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_turnaroundTime_l.Name = "lbl_turnaroundTime_l";
            this.lbl_turnaroundTime_l.Size = new System.Drawing.Size(131, 18);
            this.lbl_turnaroundTime_l.TabIndex = 7;
            this.lbl_turnaroundTime_l.Text = "Turnaround time";
            // 
            // lbl_contextSwitch
            // 
            this.lbl_contextSwitch.AutoSize = true;
            this.lbl_contextSwitch.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_contextSwitch.Location = new System.Drawing.Point(674, 320);
            this.lbl_contextSwitch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_contextSwitch.Name = "lbl_contextSwitch";
            this.lbl_contextSwitch.Size = new System.Drawing.Size(26, 31);
            this.lbl_contextSwitch.TabIndex = 6;
            this.lbl_contextSwitch.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(415, 317);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(232, 24);
            this.label10.TabIndex = 5;
            this.label10.Text = "Average Turn around:";
            // 
            // lbl_waitingTime_l
            // 
            this.lbl_waitingTime_l.AutoSize = true;
            this.lbl_waitingTime_l.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_waitingTime_l.Location = new System.Drawing.Point(146, 194);
            this.lbl_waitingTime_l.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_waitingTime_l.Name = "lbl_waitingTime_l";
            this.lbl_waitingTime_l.Size = new System.Drawing.Size(103, 18);
            this.lbl_waitingTime_l.TabIndex = 4;
            this.lbl_waitingTime_l.Text = "Waiting time";
            this.lbl_waitingTime_l.Click += new System.EventHandler(this.label5_Click);
            // 
            // lbl_avg_waitingTime
            // 
            this.lbl_avg_waitingTime.AutoSize = true;
            this.lbl_avg_waitingTime.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_avg_waitingTime.Location = new System.Drawing.Point(674, 269);
            this.lbl_avg_waitingTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_avg_waitingTime.Name = "lbl_avg_waitingTime";
            this.lbl_avg_waitingTime.Size = new System.Drawing.Size(26, 31);
            this.lbl_avg_waitingTime.TabIndex = 3;
            this.lbl_avg_waitingTime.Text = "0";
            // 
            // panel_ex_1
            // 
            this.panel_ex_1.BackColor = System.Drawing.Color.Red;
            this.panel_ex_1.Location = new System.Drawing.Point(13, 221);
            this.panel_ex_1.Name = "panel_ex_1";
            this.panel_ex_1.Size = new System.Drawing.Size(31, 28);
            this.panel_ex_1.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(415, 266);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(234, 24);
            this.label11.TabIndex = 1;
            this.label11.Text = "Average waiting time:";
            // 
            // Form_results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 550);
            this.Controls.Add(this.panel1);
            this.Name = "Form_results";
            this.Text = "Form_results";
            this.Load += new System.EventHandler(this.Form_results_Load);
            this.tabControl_GanttChart.ResumeLayout(false);
            this.tabPage_GanttChart.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_GanttChart;
        private System.Windows.Forms.TabPage tabPage_GanttChart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_waitingTime_l;
        private System.Windows.Forms.Label lbl_avg_waitingTime;
        private System.Windows.Forms.Panel panel_ex_1;
        private System.Windows.Forms.Label lbl_contextSwitch;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_p1;
        private System.Windows.Forms.Label lbl_p1_turnaroundTime;
        private System.Windows.Forms.Label lbl_p1_waitingTime;
        private System.Windows.Forms.Label lbl_turnaroundTime_l;
        private System.Windows.Forms.Label lbl_freeTime;
        private System.Windows.Forms.Panel panel_ex_0;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}